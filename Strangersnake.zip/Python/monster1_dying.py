import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
frame_size_x = 1440  # Increased width for side-by-side display
frame_size_y = 720

# Colors
black = pygame.Color(0, 0, 0)

# Initialize game window with double buffering
game_window = pygame.display.set_mode((frame_size_x, frame_size_y), pygame.DOUBLEBUF)
pygame.display.set_caption('Monster Animation')

# Function to load monster dying frames
def load_monster_dying_frames():
    monster_dying_frames = []
    for i in range(18):
        try:
            frame = pygame.image.load(f"0_Monster_Dying_{i:03}.png")
            frame = pygame.transform.scale(frame, (480, 480))  # Increase size
            monster_dying_frames.append(frame)
        except FileNotFoundError:
            print(f"File not found: 0_Monster_Dying_{i:03}.png")
            sys.exit()
    return monster_dying_frames

# Load monster frames
monster_dying_frames = load_monster_dying_frames()

# Initialize animation index and delay timer
animation_index_dying = 0
last_update_time_dying = pygame.time.get_ticks()
animation_delay = 25  # Decreased delay for faster animation

# Main loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Clear the screen
    game_window.fill(black)

    # Display dying animation
    current_time = pygame.time.get_ticks()
    if current_time - last_update_time_dying > animation_delay:
        last_update_time_dying = current_time
        current_frame_dying = monster_dying_frames[animation_index_dying]
        # Center the frame
        x = (frame_size_x - current_frame_dying.get_width()) // 2
        y = (frame_size_y - current_frame_dying.get_height()) // 2
        game_window.blit(current_frame_dying, (x, y))
        animation_index_dying = (animation_index_dying + 1) % len(monster_dying_frames)

    # Update only the region of the screen that has changed
    pygame.display.update()

    # Limit frame rate
    pygame.time.Clock().tick(60)