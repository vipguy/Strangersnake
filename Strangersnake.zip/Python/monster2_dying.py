import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
frame_size_x = 1440  # Increased width for side-by-side display
frame_size_y = 720

# Colors
black = pygame.Color(0, 0, 0)

# Initialize game window with double buffering
game_window = pygame.display.set_mode((frame_size_x, frame_size_y), pygame.DOUBLEBUF)
pygame.display.set_caption('Monster Animation')

# Function to load monster dying frames
def load_monster_dying_frames():
    monster_dying_frames = []
    for i in range(18):
        try:
            filename = f"0_Monster2_Dying_{i:03}.png"
            frame = pygame.image.load(filename)
            frame = pygame.transform.scale(frame, (480, 480))  # Increase size
            monster_dying_frames.append(frame)
        except FileNotFoundError:
            print(f"File not found: {filename}")
            sys.exit()
    return monster_dying_frames

# Load monster frames
monster_dying_frames = load_monster_dying_frames()

# Initialize animation index and delay timer
animation_index_dying = 0
animation_delay = 200  # Increased delay for slower animation

# Create a clock object to control the frame rate
clock = pygame.time.Clock()

# Main loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Clear the screen
    game_window.fill(black)

    # Display dying animation
    current_frame_dying = monster_dying_frames[animation_index_dying]
    # Center the frame
    x = (frame_size_x - current_frame_dying.get_width()) // 2
    y = (frame_size_y - current_frame_dying.get_height()) // 2
    game_window.blit(current_frame_dying, (x, y))
    animation_index_dying = (animation_index_dying + 1) % len(monster_dying_frames)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(30)  # Adjust the parameter to control the frame rate