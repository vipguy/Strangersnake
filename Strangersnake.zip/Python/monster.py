import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
frame_size_x = 1440  # Increased width for side-by-side display
frame_size_y = 720

# Colors
black = pygame.Color(0, 0, 0)

# Initialize game window
game_window = pygame.display.set_mode((frame_size_x, frame_size_y))
pygame.display.set_caption('Monster Animation')

# Function to load monster idle frames
def load_monster_idle_frames():
    monster_idle_frames = []
    for i in range(18):
        try:
            frame = pygame.image.load(f"0_Monster_idle_{i:03}.png")
            frame = pygame.transform.scale(frame, (360, 360))  # Increase size
            monster_idle_frames.append(frame)
        except FileNotFoundError:
            print(f"File not found: 0_Monster_idle_{i:03}.png")
            sys.exit()
    return monster_idle_frames

# Function to load monster dying frames
def load_monster_dying_frames():
    monster_dying_frames = []
    for i in range(18):
        try:
            frame = pygame.image.load(f"0_Monster_Dying_{i:03}.png")
            frame = pygame.transform.scale(frame, (360, 360))  # Increase size
            monster_dying_frames.append(frame)
        except FileNotFoundError:
            print(f"File not found: 0_Monster_Dying_{i:03}.png")
            sys.exit()
    return monster_dying_frames

# Load monster frames
monster_idle_frames = load_monster_idle_frames()
monster_dying_frames = load_monster_dying_frames()

# Initialize animation index and delay timer
animation_index_idle = 0
animation_index_dying = 0
last_update_time_idle = pygame.time.get_ticks()
last_update_time_dying = pygame.time.get_ticks()
animation_delay = 50  # Delay in milliseconds between frames (reduced for faster animation)

# Main loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Clear screen
    game_window.fill(black)

    # Display idle animation
    current_time = pygame.time.get_ticks()
    if current_time - last_update_time_idle > animation_delay:
        last_update_time_idle = current_time
        current_frame_idle = monster_idle_frames[animation_index_idle]
        game_window.blit(current_frame_idle, (frame_size_x // 4 - 180, frame_size_y // 2 - 180))
        animation_index_idle = (animation_index_idle + 1) % len(monster_idle_frames)

    # Display dying animation
    if current_time - last_update_time_dying > animation_delay:
        last_update_time_dying = current_time
        current_frame_dying = monster_dying_frames[animation_index_dying]
        game_window.blit(current_frame_dying, (3 * frame_size_x // 4 - 180, frame_size_y // 2 - 180))
        animation_index_dying = (animation_index_dying + 1) % len(monster_dying_frames)

    # Update the display
    pygame.display.flip()