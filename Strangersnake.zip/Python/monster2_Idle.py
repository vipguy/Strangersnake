import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
frame_size_x = 1440  # Increased width for side-by-side display
frame_size_y = 720

# Colors
black = pygame.Color(0, 0, 0)

# Initialize game window with double buffering
game_window = pygame.display.set_mode((frame_size_x, frame_size_y), pygame.DOUBLEBUF)
pygame.display.set_caption('Monster Animation')

# Function to load monster idle frames
def load_monster_idle_frames():
    monster_idle_frames = []
    for i in range(18):
        try:
            filename = f"0_Monster2_Idle_{i:03}.png"
            frame = pygame.image.load(filename)
            frame = pygame.transform.scale(frame, (480, 480))  # Increase size
            monster_idle_frames.append(frame)
        except FileNotFoundError:
            print(f"File not found: {filename}")
            sys.exit()
    return monster_idle_frames

# Load monster frames
monster_idle_frames = load_monster_idle_frames()

# Initialize animation index and delay timer
animation_index_idle = 0
last_update_time_idle = pygame.time.get_ticks()
animation_delay = 50  # Delay in milliseconds between frames (reduced for faster animation)

# Main loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Create off-screen surface for drawing
    off_screen_surface = game_window.copy()

    # Display idle animation
    current_time = pygame.time.get_ticks()
    if current_time - last_update_time_idle > animation_delay:
        last_update_time_idle = current_time
        current_frame_idle = monster_idle_frames[animation_index_idle]
        # Center the frame
        x = (frame_size_x - current_frame_idle.get_width()) // 2
        y = (frame_size_y - current_frame_idle.get_height()) // 2
        off_screen_surface.blit(current_frame_idle, (x, y))
        animation_index_idle = (animation_index_idle + 1) % len(monster_idle_frames)

    # Swap the off-screen surface with the display
    pygame.display.flip()
    game_window.blit(off_screen_surface, (0, 0))